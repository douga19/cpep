#include "Fonctions.h"

int main() {

        double res = 0.;

        while (1)
        {
            double a;
            double b;
            char op;

            printf("> ");
            int n = scanf("%lf %lf %c", &a, &b, &op);

            if (n <= 1)
            {
                scanf("%c", &op);
                b = a;
                a = res;
            }
            if (op == 'q')
                break;

            switch (op)
            {
                case '+':
                    res = a + b;
                    break;

                case '-':
                    res = a - b;
                    break;

                case '*':
                    res = a * b;
                    break;

                case '/':
                    res = a / b;
                    break;

                case '%':
                    res = (long long)a % (long long)b;
                    break;

                case '^':
                    res = pow(a, b);
                    break;

                case '!':
                    res = factorielle((n == 0) ? a : b);
                    break;

                case 'g':
                    res = pgcd(a, b);
                    break;

                case 'p':
                    res = ppcd(a, b);
                    break;
            }

            printf("%lf\n", res);
        }
        return 0;

}
