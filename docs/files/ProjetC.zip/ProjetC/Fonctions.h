//
// Created by guira on 13/07/2022.
//

#ifndef PROJET_LINUX_FONCTIONS_H
#define PROJET_LINUX_FONCTIONS_H
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

float calculatrice (float, float);
long long pgcd(long long, long long);
long long ppcd(long long, long long);
unsigned long long factorielle(unsigned long long);
#endif //PROJET_LINUX_FONCTIONS_H
