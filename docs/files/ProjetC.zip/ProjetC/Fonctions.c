
#include "Fonctions.h"

float calculatrice (float a, float b){

    return 0;
}

long long pgcd(long long a, long long b)
{
    if (b == 0)
        return a;

    long long r = a % b;

    while (r != 0)
    {
        a = b;
        b = r;
        r = a % b;
    }

    return b;
}


long long ppcd(long long a, long long b)
{
    if (a == 0 || b == 0)
        return 0;

    long long max = (a > b) ? a : b;
    long long i = max;

    while (i % a != 0 || i % b != 0)
        ++i;

    return i;
}


unsigned long long factorielle(unsigned long long a)
{
    unsigned long long r = 1;

    for (unsigned long long i = 2; i <= a; ++i)
        r *= i;

    return r;
}





